using System;
using System.Web.UI;

namespace NTier.Web
{
    public class CDefault : Page
    {
        public CDefault()
        {
            Page.Init += Page_Init;
        }

        private void Page_Load(object sender, EventArgs e)
        {
            //NTier.WebService.NTier ws = new NTier.WebService.NTier();
            //Response.Write("User ID: " + ws.Login("ssmith@aspalliance.com","secret"));
        }

        private void Page_Init(object sender, EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
        }

        #region Web Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.Page_Load);
        }

        #endregion
    }
}