﻿using System;
using NTier.BLL;

namespace NTier.Data.Sql
{
    public class SqlUserRepository : IUserRepository
    {
        public int GetByEmailPassword(string email, string password)
        {
            throw new NotImplementedException();
        }
    }
}