﻿namespace NTier.BLL
{
    public interface IUserRepository
    {
        int GetByEmailPassword(string email, string password);
    }
}