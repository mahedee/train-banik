﻿namespace ExtractTransformLoad
{
    public class Employee
    {
        public string Name;
        public bool IsManager;
        public decimal Bonus;
    }
}