﻿namespace ExtractTransformLoad
{
    public class FreightByShipper
    {
        public string ShipperName;
        public decimal Freight;
    }
}