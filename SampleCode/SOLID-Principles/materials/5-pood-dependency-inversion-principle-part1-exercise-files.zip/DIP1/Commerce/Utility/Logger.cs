using System;

namespace Commerce.Utility
{
    public static class Logger
    {
        public static void Error(string message, Exception exception)
        {
        }
    }
}