namespace ExtractTransformLoad
{
    public static class Format
    {
        public const string FreightFormatString = "{0}:{1:#.##}";
    }
}